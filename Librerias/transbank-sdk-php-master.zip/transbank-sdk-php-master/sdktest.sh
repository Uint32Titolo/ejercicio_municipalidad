#!/bin/bash

./vendor/bin/phpunit
