<?php

namespace Transbank\Onepay;

class ChannelEnum
{

    public static function WEB() {
        return 'WEB';
    }

    public static function MOBILE() {
        return 'MOBILE';
    }

    public static function APP() {
        return 'APP';
    }
}