<?php
namespace Transbank\Webpay;

class initTransactionResponse {
    var $return; //wsInitTransactionOutput
}
