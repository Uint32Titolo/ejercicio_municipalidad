<?php
namespace Transbank\Webpay;

class wsInitTransactionOutput {
    public $token; //string
    public $url; //string
}
