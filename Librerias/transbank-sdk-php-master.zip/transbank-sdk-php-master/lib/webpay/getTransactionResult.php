<?php
namespace Transbank\Webpay;

class getTransactionResult {
    var $tokenInput; //string
}
