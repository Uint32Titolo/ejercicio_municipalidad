<?php
namespace Transbank\Webpay;

class acknowledgeTransactionResponse {
}
