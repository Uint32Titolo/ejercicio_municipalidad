<?php
namespace Transbank\Webpay;

class initTransaction {
    var $wsInitTransactionInput; //wsInitTransactionInput
}
