<?php
namespace Transbank\Webpay;

class wsTransactionDetailOutput {
    var $authorizationCode; //string
    var $paymentTypeCode; //string
    var $responseCode; //int
}
