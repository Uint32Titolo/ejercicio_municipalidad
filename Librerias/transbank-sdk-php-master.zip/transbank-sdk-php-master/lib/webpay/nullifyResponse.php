<?php
namespace Transbank\Webpay;

class nullifyResponse {
    var $return; //nullificationOutput
}
