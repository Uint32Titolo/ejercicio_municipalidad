<?php
namespace Transbank\Webpay;

class baseBean {
}
