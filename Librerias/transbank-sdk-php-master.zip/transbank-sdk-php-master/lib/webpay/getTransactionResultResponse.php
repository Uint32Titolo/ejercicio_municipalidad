<?php
namespace Transbank\Webpay;

class getTransactionResultResponse {
    var $return; //transactionResultOutput
}
