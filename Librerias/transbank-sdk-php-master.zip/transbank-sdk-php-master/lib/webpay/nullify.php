<?php
namespace Transbank\Webpay;

class nullify {
    var $nullificationInput;
}
