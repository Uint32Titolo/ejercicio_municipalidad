<?php
namespace Transbank\Webpay;

class wsTransactionDetail {
    var $sharesAmount; //decimal
    var $sharesNumber; //int
    var $amount; //decimal
    var $commerceCode; //string
    var $buyOrder; //string
}
