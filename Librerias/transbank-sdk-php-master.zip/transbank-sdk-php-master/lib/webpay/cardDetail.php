<?php
namespace Transbank\Webpay;

class cardDetail {
    var $cardNumber; //string
    var $cardExpirationDate; //string
}
