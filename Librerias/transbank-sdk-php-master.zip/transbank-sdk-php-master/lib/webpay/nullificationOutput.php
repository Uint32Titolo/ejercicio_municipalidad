<?php
namespace Transbank\Webpay;

class nullificationOutput {
    var $authorizationCode; //string
    var $authorizationDate; //dateTime
    var $balance; //decimal
    var $nullifiedAmount; //decimal
    var $token; //string
}
