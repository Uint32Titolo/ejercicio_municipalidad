<?php
namespace Transbank\Webpay;

class acknowledgeTransaction {
    var $tokenInput; //string
}
